%x = input
a = -5:0.5:5;
x = 64*triangularPulse(-3,3,a);

%h = filter
b = -3:0.5:3;
h = 2*triangularPulse(-1,1,b);

withfi = conv_fixed(x,h,8,2,8,2)
without = my_conv(x,h)

diff = without - withfi
sequre = diff.^2
ems = mean(sequre)

function f=my_conv(x,h)
    %preconvolution
    len_m = length(x);
    len_n = length(h);
    ze = zeros(1, len_n-1);
    x1 = [ze, x, ze];
    rotat_h = flip(h, 2);
    %convolution
    for i=1:len_m+len_n-1
        f(i) = 0;
        for j=1:len_n
            f(i) = f(i) + rotat_h(j) * x1(i+j-1);
        end
    end
end

function f = conv_fixed(x, h, xm, xn, hm, hn)
    x=fi(x,0,xm+xn,xn)
    h=fi(h,0,hm+hn,hn)
    
    %preconvolution
    len_m = length(x);
    len_n = length(h);
    
    ze = zeros(1, len_n-1);
    ze = fi(ze,0,xm+xn,xn);
    x1 = [ze, x, ze];
    rotat_h = flip(h, 2);
    f=fi(0,0,xn+xm+hn+hm+4,xn+hn);
    %convolution
    for i=1:len_m+len_n-1
        f(i) = 0;
        for j=1:len_n
            f(i) = f(i) + rotat_h(j) * x1(i+j-1);
        end
    end
end