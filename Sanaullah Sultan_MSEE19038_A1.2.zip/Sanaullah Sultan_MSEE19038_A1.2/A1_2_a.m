%x = input
a = -5:0.5:5;
x = 64*triangularPulse(-3,3,a);

%h = filter
b = -3:0.5:3;
h = 2*triangularPulse(-1,1,b);

%preconvolution
len_m = length(x);
len_n = length(h);

ze = zeros(1, len_n-1);
u1 = cat(2, ze, x, ze);
rotat_h = flip(h, 2);

%convolution
for i=1:len_m+len_n-1
    w(i) = 0;
    for j=1:len_n
    	w(i) = w(i) + rotat_h(j) * u1(i+j-1);
    end
end
w

orig = conv(x,h)

diff = orig - w

