%x = input
a = -5:0.5:5;
x = 64*triangularPulse(-3,3,a);

%h = filter
b = -3:0.5:3;
h = 2*triangularPulse(-1,1,b);

nofi = conv(x,h)

x1=fi(x,0,10,2)
h1=fi(h,0,10,2)

withfi = conv(x1,h1)

diff = nofi - withfi
sequre = diff.^2
ems = mean(sequre)